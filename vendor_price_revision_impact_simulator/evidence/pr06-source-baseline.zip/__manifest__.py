# License approval is pending. The Odoo loader defaults an omitted license to
# LGPL-3; see README.md for the required release decision before distribution.

{
    "name": "Vendor Price Revision Impact Simulator",
    "summary": "Foundation for a supplier price revision impact workflow.",
    "version": "20.0.1.0.0",
    "category": "Supply Chain/Purchase",
    "description": """
Vendor Price Revision Impact Simulator
=======================================

This module records supplier price revision drafts and proposed price lines,
preserves original CSV/XLSX evidence, and supports raw extraction, column mapping,
structural validation and traceable correction review. Product resolution,
commercial normalization, financial simulation, approval execution, reporting,
and vendor price changes are deferred to later development steps.
""",
    "depends": ["base", "product"],
    "external_dependencies": {"python": ["openpyxl", "lxml"]},
    "data": [
        "security/vendor_revision_security.xml",
        "data/vendor_revision_sequence.xml",
        "views/vendor_revision_views.xml",
        "views/vendor_revision_menus.xml",
        "security/revision_config_security.xml",
        "views/revision_config_views.xml",
        "security/import_intake_security.xml",
        "views/import_intake_views.xml",
        "security/import_validation_security.xml",
        "views/import_validation_views.xml",
    ],
    "application": True,
    "installable": True,
}
