# License approval is pending. The Odoo loader defaults an omitted license to
# LGPL-3; see README.md for the required release decision before distribution.

{
    "name": "Vendor Price Revision Impact Simulator",
    "summary": "Foundation for a supplier price revision impact workflow.",
    "version": "20.0.1.0.0",
    "category": "Supply Chain/Purchase",
    "description": """
Vendor Price Revision Impact Simulator
=======================================

This module records supplier price revision drafts and proposed price lines,
preserves original CSV/XLSX evidence, and supports raw extraction, column mapping,
structural validation, traceable correction review, and exact variant resolution
with independently verified vendor mappings and immutable commercial price
normalization/comparison snapshots. Financial exposure, approval execution,
reporting and vendor price changes are deferred to later development steps.
""",
    "depends": ["base", "product", "purchase_stock", "sale_stock"],
    "external_dependencies": {"python": ["openpyxl", "lxml"]},
    "data": [
        "security/vendor_revision_security.xml",
        "data/vendor_revision_sequence.xml",
        "views/vendor_revision_views.xml",
        "views/vendor_revision_menus.xml",
        "security/revision_config_security.xml",
        "views/revision_config_views.xml",
        "security/import_intake_security.xml",
        "views/import_intake_views.xml",
        "security/import_validation_security.xml",
        "views/import_validation_views.xml",
        "security/product_resolution_security.xml",
        "views/product_resolution_views.xml",
        "security/commercial_validation_security.xml",
        "views/commercial_validation_views.xml",
        "security/supply_security.xml",
        "views/supply_views.xml",
        "security/allocation_security.xml",
        "views/allocation_views.xml",
        "security/sales_exposure_security.xml",
        "views/sales_exposure_views.xml",
        "security/purchase_commitment_security.xml",
        "views/purchase_commitment_views.xml",
        "security/cost_attribution_security.xml",
        "views/cost_attribution_views.xml",
        "security/financial_exposure_security.xml",
        "security/profitability_security.xml",
        "security/reconciliation_security.xml",
        "security/scenario_security.xml",
        "views/financial_exposure_views.xml",
        "views/profitability_views.xml",
        "views/reconciliation_views.xml",
        "views/scenario_views.xml",
    ],
    "application": True,
    "installable": True,
}
