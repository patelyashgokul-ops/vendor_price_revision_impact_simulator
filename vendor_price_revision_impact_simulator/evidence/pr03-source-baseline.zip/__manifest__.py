# License approval is pending. The Odoo loader defaults an omitted license to
# LGPL-3; see README.md for the required release decision before distribution.

{
    "name": "Vendor Price Revision Impact Simulator",
    "summary": "Foundation for a supplier price revision impact workflow.",
    "version": "20.0.1.0.0",
    "category": "Supply Chain/Purchase",
    "description": """
Vendor Price Revision Impact Simulator
=======================================

This module records supplier price revision drafts, proposed price lines, and
references to source evidence. Import, financial simulation, approval,
reporting, and vendor price changes are deferred to later development steps.
""",
    "depends": ["base", "product"],
    "data": [
        "security/vendor_revision_security.xml",
        "data/vendor_revision_sequence.xml",
        "views/vendor_revision_views.xml",
        "views/vendor_revision_menus.xml",
    ],
    "application": True,
    "installable": True,
}
